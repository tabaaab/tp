package tp4;

public class vol {

	private String identif;
	private ZonedDateTime depart;
	private ZonedDateTime arrivee;
	private State etat;


	private vol(String identif , ZonedDateTime depart , ZonedDateTime arrivee){
		this.identif=identif;
		this.depart=depart;
		this.arrivee=arrivee;
		etat=OUVERT;
	}

	private reservation r = new reservation();


	enum State{
        OUVERT,
        FERME
    }


    public int duree(){
        return arrivee.getMinute()-depart.getMinute();
    }



    public void ouvrir() throws IllegalStateException{
        if (etat.equals(State.OUVERT)) throw new IllegalStateException("vole ouvert");
        else etat = State.OUVERT;

    }


     public void fermer() throws IllegalStateException{
        if (etat.equals(State.FERME)) throw new IllegalStateException("vole fermer");
        else etat = State.FERME;
    }



    }

}
