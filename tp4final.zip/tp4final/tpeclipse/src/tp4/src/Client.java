package tp4;
import java.util.*;
public final class Client {
	
	
	private String nom ;
	private String paiement;
	private String contact;
	private String referance ;
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	

	public void reserver(Vol vol, Passager passager, String identifiant){
        try{
            Reservation res = vol.creerReservation(vol, this, passager, id);
        }catch(IllegalStateException ex){
            System.err.println(ex.getMessage());
        }
    }

    public void confirmerReservation(String referance) throws IllegalStateException, IllegalArgumentException{
	findReservation(id).confirmer();
    }

    

    public void payerReservation(String referance) throws IllegalArgumentException, IllegalArgumentException{
	findReservation(id).payer();
    }

    public void annulerReservation(String id) throws IllegalArgumentException{
       	findReservation(id).annuler();
    }

    private Reservation findReservation(String id) throws IllegalArgumentException{
        Iterator<Reservation> it = reservations.iterator();
        while (it.hasNext()){
            Reservation res = it.next();
            if (res.aIdentifiant(id)) return res;
        }
        throw new IllegalArgumentException();
    }

    public void ajouterReservation(Reservation reservation){
        reservations.add(reservation);
    }

    
    }

    public void ajouterRemboursement(String id, double prix){
	remboursements.put(id, prix);
    }
	

}
