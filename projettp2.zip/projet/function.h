#include <stdio.h>
//#include <stdlib.h>
int function(char * name) ;
