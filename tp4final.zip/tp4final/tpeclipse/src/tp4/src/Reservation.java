package tp4;
import java.util.*;

import java.time.ZonedDateTime;

public class Reservation {
	
	private ZonedDateTime date;
	private double id;
	private String etat;
	

	enum State{
        EN_ATTENTE,
        PAYEE,
        CONFIRMEE,
        ANNULEE
    }

    private vol v = new vol();
	
	public Reservation(ZonedDateTime date, double  id, 
            String etat) 
						{ 
		this.date = date; 
		this.id = id; 
		this.etat = etat; 
           }
	
	public ZonedDateTime getdate() {
		return date;
		
	}
	
	public double getid() {
		return id;
	}
	
	public String getetat() {
		return etat;
	}
	
	//public void annuler()
	//public void confirmer()
	//public void payer() 



	public void annuler(){
        switch(etat){
            case EN_ATTENTE:
                etat = State.ANNULEE;
            case PAYEE:
                etat = State.ANNULEE;
                /*Remboursement */
		client.ajouterRemboursement(id, vol.getPrix());
            case ANNULEE:
                System.out.println("reservation annuler");
            case CONFIRMEE:
                etat = State.ANNULEE;
        }
    }



    public void confirmer() throws IllegalStateException{
        switch(etat){
            case EN_ATTENTE:
                throw new IllegalStateException("payer avant confirmer");
            case PAYEE:
                etat = State.CONFIRMEE;
            case ANNULEE:
                throw new IllegalStateException("reservation annuler");
            case CONFIRMEE:
                System.out.println("deja confirmer");
        }
    }
	
	
	
	public void payer() throws IllegalStateException{
        switch(etat){
            case EN_ATTENTE:
		client.ajouterPaiement(identifiant, vol.getPrix());
                etat = State.PAYEE;	
            case PAYEE:
                throw new IllegalStateException("Ydeja payer");
            case ANNULEE:
                throw new IllegalStateException("reservation annuler");
            case CONFIRMEE:
                throw new IllegalStateException("deja payer et confirmer");
        }
    }
	
	
	
	
	

}
