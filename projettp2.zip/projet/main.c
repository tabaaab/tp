#include <stdio.h>
#include <stdlib.h>
#include "function.h"
int main(int argc, char ** argv){
function(argv[1]) ;
return 0 ;
}
