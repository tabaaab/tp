#include <stdio.h>
#include <stdlib.h>
#include "function.h"
int function(char * name){
printf("hello heello %s !\n",name) ;
return 0 ;
}
