package tp4;

public class passager {

	String nom;
	String contact;
	
	
	public passager(String nom, String contact) 
    { 
 this.nom = nom; 
 this.contact = contact; 
 
    } 
	
	
	
}